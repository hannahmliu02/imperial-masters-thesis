# Erosion comparison — ablation vs LoRA vs OFT

Identified candidate: layer [31], k=5, alignment=0.9688252120252725.

| method | n_train | bias | capability | update·D (max cos) | demo-strength after | cos(new,D) | proj-gap after |
|---|---|---|---|---|---|---|---|
| none (G_p) | 0 | 1.000 | 0.800 |  |  |  |  |
| ablation | None | 0.210 | 0.800 |  |  |  |  |
| lora | 100 | 0.001 | 0.778 | 0.467 | 8.465 | 0.431 | 3.651 |
| lora | 500 | 0.000 | 0.900 | 0.445 | 5.017 | 0.545 | 2.733 |
| lora | 1000 | 0.000 | 1.000 | 0.456 | 4.295 | 0.537 | 2.307 |
| lora | 1000 | 0.000 | 1.000 | 0.454 | 5.266 | 0.610 | 3.211 |
| oft | 100 | 0.046 |  | 0.345 | 9.555 | 0.050 | 0.482 |
| oft | 500 | 0.000 |  | 0.359 | 6.899 | 0.161 | 1.112 |
| oft | 1000 | 0.000 |  | 0.332 | 10.324 | 0.206 | 2.130 |
| oft | 1000 | 0.000 |  | 0.357 | 5.047 | 0.076 | 0.384 |

_Bias should fall with erosion; high update·D overlap means the fine-tuning moved along the identified direction; a shrinking proj-gap means the bias was removed in D's coordinates._