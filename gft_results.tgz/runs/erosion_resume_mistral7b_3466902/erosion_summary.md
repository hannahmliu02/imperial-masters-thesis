# Erosion comparison — ablation vs LoRA vs OFT

Identified candidate: layer [31], k=5, alignment=0.9454975650452275.

| method | n_train | bias | capability | update·D (max cos) | demo-strength after | cos(new,D) | proj-gap after |
|---|---|---|---|---|---|---|---|
| none (G_p) | 0 | 1.000 | 0.800 |  |  |  |  |
| ablation | None | 0.359 | 0.900 |  |  |  |  |
| lora | 100 | 0.230 | 0.900 | 0.433 | 5.405 | 0.442 | 2.388 |
| lora | 500 | 0.000 | 0.900 | 0.495 | 3.560 | 0.172 | 0.614 |
| lora | 1000 | 0.000 | 0.800 | 0.467 | 3.181 | 0.191 | 0.609 |
| lora | 1000 | 0.000 | 0.750 | 0.478 | 2.883 | 0.227 | 0.655 |
| oft | 100 | 0.002 |  | 0.415 | 2.830 | -0.050 | 0.141 |
| oft | 500 | 0.003 |  | 0.408 | 2.582 | 0.097 | 0.250 |
| oft | 1000 | 0.000 |  | 0.414 | 6.836 | 0.156 | 1.068 |
| oft | 1000 | 0.000 |  | 0.397 | 7.201 | 0.289 | 2.079 |

_Bias should fall with erosion; high update·D overlap means the fine-tuning moved along the identified direction; a shrinking proj-gap means the bias was removed in D's coordinates._