# Erosion comparison — ablation vs LoRA vs OFT

Identified candidate: layer [29], k=5, alignment=0.9712689236242567.

| method | n_train | bias | capability | update·D (max cos) | demo-strength after | cos(new,D) | proj-gap after |
|---|---|---|---|---|---|---|---|
| none (G_p) | 0 | 1.000 | 0.800 |  |  |  |  |
| ablation | None | 0.156 | 0.800 |  |  |  |  |
| lora | 100 | 0.001 | 0.750 | 0.292 | 6.476 | 0.828 | 5.362 |
| lora | 500 | 0.000 | 0.800 | 0.304 | 6.024 | 0.807 | 4.864 |
| lora | 1000 | 0.000 | 0.750 | 0.294 | 3.103 | 0.548 | 1.702 |
| lora | 1000 | 0.000 | 1.000 | 0.295 | 2.644 | 0.340 | 0.898 |
| oft | 100 | 0.019 |  | 0.295 | 3.103 | 0.150 | 0.464 |
| oft | 500 | 0.000 |  | 0.241 | 2.631 | 0.162 | 0.426 |
| oft | 1000 | 0.000 |  | 0.277 | 6.873 | 0.368 | 2.532 |
| oft | 1000 | 0.000 |  | 0.249 | 3.881 | 0.195 | 0.755 |

_Bias should fall with erosion; high update·D overlap means the fine-tuning moved along the identified direction; a shrinking proj-gap means the bias was removed in D's coordinates._