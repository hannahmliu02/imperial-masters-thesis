# Erosion comparison — ablation vs LoRA vs OFT

Identified candidate: layer [31], k=5, alignment=0.9706768903950608.

| method | n_train | bias | capability | update·D (max cos) | demo-strength after | cos(new,D) | proj-gap after |
|---|---|---|---|---|---|---|---|
| none (G_p) | 0 | 1.000 | 0.900 |  |  |  |  |
| ablation | None | 0.084 | 0.900 |  |  |  |  |
| lora | 100 | 0.000 | 0.500 | 0.516 | 5.214 | 0.603 | 3.142 |
| lora | 200 | 0.000 | 0.800 | 0.501 | 6.730 | 0.609 | 4.101 |
| lora | 300 | 0.000 |  | 0.508 | 4.665 | 0.527 | 2.459 |
| lora | 400 | 0.000 | 0.750 | 0.481 | 4.010 | 0.538 | 2.158 |
| lora | 500 | 0.000 | 0.900 | 0.454 | 6.446 | 0.569 | 3.669 |
| lora | 750 | 0.000 | 0.667 | 0.456 | 3.631 | 0.315 | 1.144 |
| lora | 1000 | 0.000 | 0.875 | 0.440 | 5.182 | 0.572 | 2.965 |

_Bias should fall with erosion; high update·D overlap means the fine-tuning moved along the identified direction; a shrinking proj-gap means the bias was removed in D's coordinates._