# Erosion comparison — ablation vs LoRA vs OFT

Identified candidate: layer [31], k=5, alignment=0.9514190788236668.

| method | n_train | bias | capability | update·D (max cos) | demo-strength after | cos(new,D) | proj-gap after |
|---|---|---|---|---|---|---|---|
| none (G_p) | 0 | 1.000 | 0.800 |  |  |  |  |
| ablation | None | 0.979 | 0.900 |  |  |  |  |
| lora | 100 | 0.005 | 0.889 | 0.406 | 2.941 | 0.130 | 0.383 |
| lora | 500 | 0.000 | 0.800 | 0.450 | 5.170 | 0.608 | 3.141 |
| lora | 1000 | 0.000 | 0.900 | 0.476 | 2.613 | 0.169 | 0.441 |
| lora | 1000 | 0.000 | 1.000 | 0.466 | 3.636 | 0.069 | 0.250 |
| oft | 100 | 0.001 |  | 0.389 | 5.669 | 0.040 | 0.225 |
| oft | 500 | 0.001 |  | 0.414 | 5.806 | 0.058 | 0.335 |
| oft | 1000 | 0.004 |  | 0.412 | 17.175 | 0.013 | 0.217 |
| oft | 1000 | 0.000 |  | 0.423 | 2.726 | 0.040 | 0.110 |

_Bias should fall with erosion; high update·D overlap means the fine-tuning moved along the identified direction; a shrinking proj-gap means the bias was removed in D's coordinates._