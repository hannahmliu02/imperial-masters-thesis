# Erosion comparison — ablation vs LoRA vs OFT

Identified candidate: layer [29], k=5, alignment=0.9349904918126704.

| method | n_train | bias | capability | update·D (max cos) | demo-strength after | cos(new,D) | proj-gap after |
|---|---|---|---|---|---|---|---|
| none (G_p) | 0 | 1.000 | 0.556 |  |  |  |  |
| ablation | None | 0.008 | 0.556 |  |  |  |  |
| lora | 100 | 0.003 | 0.500 | 0.241 | 5.951 | 0.807 | 4.802 |
| lora | 500 | 0.000 | 0.667 | 0.277 | 4.676 | 0.651 | 3.044 |
| lora | 1000 | 0.000 | 0.500 | 0.281 | 4.782 | 0.621 | 2.971 |
| lora | 1000 | 0.000 | 0.500 | 0.261 | 4.773 | 0.615 | 2.936 |
| oft | 100 | 0.177 |  | 0.182 | 9.645 | 0.673 | 6.495 |
| oft | 500 | 0.000 |  | 0.282 | 7.130 | 0.443 | 3.155 |
| oft | 1000 | 0.000 |  | 0.336 | 8.193 | 0.569 | 4.663 |
| oft | 1000 | 0.000 |  | 0.319 | 5.289 | 0.080 | 0.422 |

_Bias should fall with erosion; high update·D overlap means the fine-tuning moved along the identified direction; a shrinking proj-gap means the bias was removed in D's coordinates._