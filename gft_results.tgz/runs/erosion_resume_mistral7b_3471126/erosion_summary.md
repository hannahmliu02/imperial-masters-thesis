# Erosion comparison — ablation vs LoRA vs OFT

Identified candidate: layer [29], k=5, alignment=0.9643202415315657.

| method | n_train | bias | capability | update·D (max cos) | demo-strength after | cos(new,D) | proj-gap after |
|---|---|---|---|---|---|---|---|
| none (G_p) | 0 | 1.000 | 0.800 |  |  |  |  |
| ablation | None | 0.478 | 0.800 |  |  |  |  |
| lora | 100 | 0.266 | 0.600 | 0.313 | 7.403 | 0.483 | 3.574 |
| lora | 500 | 0.000 |  | 0.359 | 2.528 | 0.223 | 0.564 |
| lora | 1000 | 0.000 | 1.000 | 0.331 | 2.658 | 0.365 | 0.970 |
| lora | 1000 | 0.000 | 1.000 | 0.333 | 2.825 | 0.404 | 1.142 |
| oft | 100 | 0.009 |  | 0.271 | 7.147 | 0.200 | 1.430 |
| oft | 500 | 0.000 |  | 0.261 | 7.327 | 0.473 | 3.466 |
| oft | 1000 | 0.000 |  | 0.347 | 9.338 | 0.554 | 5.177 |
| oft | 1000 | 0.000 |  | 0.336 | 8.116 | 0.373 | 3.029 |

_Bias should fall with erosion; high update·D overlap means the fine-tuning moved along the identified direction; a shrinking proj-gap means the bias was removed in D's coordinates._