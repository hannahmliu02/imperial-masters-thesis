# Erosion comparison — ablation vs LoRA vs OFT

Identified candidate: layer [31], k=5, alignment=0.9618825894786717.

| method | n_train | bias | capability | update·D (max cos) | demo-strength after | cos(new,D) | proj-gap after |
|---|---|---|---|---|---|---|---|
| none (G_p) | 0 | 1.000 | 0.900 |  |  |  |  |
| ablation | None | 0.129 | 0.900 |  |  |  |  |
| lora | 100 | 0.001 | 1.000 | 0.457 | 5.809 | 0.512 | 2.976 |
| lora | 200 | 0.000 | 0.900 | 0.496 | 4.238 | 0.395 | 1.672 |
| lora | 300 | 0.000 | 1.000 | 0.457 | 3.985 | 0.247 | 0.986 |
| lora | 400 | 0.000 | 0.900 | 0.498 | 4.000 | 0.406 | 1.625 |
| lora | 500 | 0.000 | 1.000 | 0.479 | 4.512 | 0.481 | 2.172 |
| lora | 750 | 0.000 | 1.000 | 0.468 | 3.928 | 0.475 | 1.867 |
| lora | 1000 | 0.000 | 0.667 | 0.467 | 4.355 | 0.344 | 1.498 |
| oft | 100 | 0.074 |  | 0.318 | 8.252 | 0.216 | 1.786 |
| oft | 200 | 0.059 |  | 0.343 | 7.048 | 0.091 | 0.638 |
| oft | 300 | 0.000 |  | 0.348 | 2.996 | -0.039 | 0.117 |
| oft | 400 | 0.000 |  | 0.310 | 2.568 | -0.000 | 0.000 |
| oft | 500 | 0.000 |  | 0.359 | 3.036 | 0.081 | 0.245 |
| oft | 750 | 0.000 |  | 0.332 | 5.489 | 0.207 | 1.137 |
| oft | 1000 | 0.000 |  | 0.344 | 3.494 | 0.252 | 0.879 |

_Bias should fall with erosion; high update·D overlap means the fine-tuning moved along the identified direction; a shrinking proj-gap means the bias was removed in D's coordinates._