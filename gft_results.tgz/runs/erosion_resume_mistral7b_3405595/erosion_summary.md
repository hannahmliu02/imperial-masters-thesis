# Erosion comparison — ablation vs LoRA vs OFT

Identified candidate: layer [31], k=5, alignment=0.9318547166362808.

| method | n_train | bias | capability | update·D (max cos) | demo-strength after | cos(new,D) | proj-gap after |
|---|---|---|---|---|---|---|---|
| none (G_p) | 0 | 1.000 | 0.600 |  |  |  |  |
| ablation | None | 0.989 | 0.600 |  |  |  |  |
| lora | 100 | 0.187 | 1.000 | 0.463 | 5.580 | 0.487 | 2.719 |
| lora | 500 | 0.000 | 0.667 | 0.535 | 4.527 | 0.583 | 2.638 |
| lora | 1000 | 0.000 | 0.600 | 0.486 | 5.460 | 0.475 | 2.591 |
| lora | 1000 | 0.000 | 1.000 | 0.489 | 5.632 | 0.434 | 2.443 |
| oft | 100 | 0.002 |  | 0.359 | 13.502 | 0.081 | 1.095 |
| oft | 500 | 0.001 |  | 0.388 | 37.850 | 0.093 | 3.516 |
| oft | 1000 | 0.007 |  | 0.418 | 21.989 | 0.071 | 1.553 |
| oft | 1000 | 0.000 |  | 0.431 | 34.062 | 0.120 | 4.077 |

_Bias should fall with erosion; high update·D overlap means the fine-tuning moved along the identified direction; a shrinking proj-gap means the bias was removed in D's coordinates._