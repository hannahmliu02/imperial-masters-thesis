# Erosion comparison — ablation vs LoRA vs OFT

Identified candidate: layer [14], k=5, alignment=0.9189263559167787.

| method | n_train | bias | capability | update·D (max cos) | demo-strength after | cos(new,D) | proj-gap after |
|---|---|---|---|---|---|---|---|
| none (G_p) | 0 | 0.001 |  |  |  |  |  |
| ablation | None | 0.001 |  |  |  |  |  |

_Bias should fall with erosion; high update·D overlap means the fine-tuning moved along the identified direction; a shrinking proj-gap means the bias was removed in D's coordinates._