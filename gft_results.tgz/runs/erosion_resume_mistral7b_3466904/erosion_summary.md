# Erosion comparison — ablation vs LoRA vs OFT

Identified candidate: layer [29], k=5, alignment=0.9751076870042383.

| method | n_train | bias | capability | update·D (max cos) | demo-strength after | cos(new,D) | proj-gap after |
|---|---|---|---|---|---|---|---|
| none (G_p) | 0 | 1.000 | 0.800 |  |  |  |  |
| ablation | None | 0.092 | 0.800 |  |  |  |  |
| lora | 100 | 0.008 | 0.800 | 0.227 | 6.456 | 0.732 | 4.723 |
| lora | 500 | 0.000 | 0.900 | 0.263 | 5.648 | 0.669 | 3.776 |
| lora | 1000 | 0.000 | 0.900 | 0.316 | 5.507 | 0.694 | 3.821 |
| lora | 1000 | 0.000 | 0.800 | 0.299 | 5.757 | 0.726 | 4.181 |
| oft | 100 | 0.000 |  | 0.245 | 3.375 | -0.031 | 0.105 |
| oft | 500 | 0.000 |  | 0.190 | 9.599 | 0.111 | 1.066 |
| oft | 1000 | 0.000 |  | 0.364 | 2.793 | 0.055 | 0.154 |
| oft | 1000 | 0.000 |  | 0.337 | 3.610 | 0.027 | 0.098 |

_Bias should fall with erosion; high update·D overlap means the fine-tuning moved along the identified direction; a shrinking proj-gap means the bias was removed in D's coordinates._