# Erosion comparison — ablation vs LoRA vs OFT

Identified candidate: layer [31], k=5, alignment=0.9359405677798943.

| method | n_train | bias | capability | update·D (max cos) | demo-strength after | cos(new,D) | proj-gap after |
|---|---|---|---|---|---|---|---|
| none (G_p) | 0 | 1.000 | 0.800 |  |  |  |  |
| ablation | None | 0.091 | 0.800 |  |  |  |  |
| lora | 100 | 0.051 | 0.900 | 0.504 | 5.689 | 0.641 | 3.646 |
| lora | 500 | 0.000 | 0.800 | 0.478 | 5.189 | 0.673 | 3.491 |
| lora | 1000 | 0.000 | 0.800 | 0.446 | 5.336 | 0.673 | 3.594 |
| lora | 1000 | 0.000 | 0.800 | 0.436 | 5.594 | 0.686 | 3.837 |
| oft | 100 | 0.086 |  | 0.454 | 6.426 | 0.191 | 1.224 |
| oft | 500 | 0.000 |  | 0.427 | 4.020 | 0.123 | 0.493 |
| oft | 1000 | 0.000 |  | 0.420 | 7.469 | 0.231 | 1.726 |
| oft | 1000 | 0.000 |  | 0.386 | 5.313 | 0.087 | 0.464 |

_Bias should fall with erosion; high update·D overlap means the fine-tuning moved along the identified direction; a shrinking proj-gap means the bias was removed in D's coordinates._