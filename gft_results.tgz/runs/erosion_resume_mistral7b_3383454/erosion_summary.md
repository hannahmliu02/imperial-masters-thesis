# Erosion comparison — ablation vs LoRA vs OFT

Identified candidate: layer [30], k=5, alignment=0.9432893548592166.

| method | n_train | bias | capability | update·D (max cos) | demo-strength after | cos(new,D) | proj-gap after |
|---|---|---|---|---|---|---|---|
| none (G_p) | 0 | 0.000 |  |  |  |  |  |
| ablation | None | 0.000 |  |  |  |  |  |

_Bias should fall with erosion; high update·D overlap means the fine-tuning moved along the identified direction; a shrinking proj-gap means the bias was removed in D's coordinates._