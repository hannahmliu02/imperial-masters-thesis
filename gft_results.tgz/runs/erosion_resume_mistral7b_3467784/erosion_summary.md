# Erosion comparison — ablation vs LoRA vs OFT

Identified candidate: layer [29], k=5, alignment=0.9623263624943837.

| method | n_train | bias | capability | update·D (max cos) | demo-strength after | cos(new,D) | proj-gap after |
|---|---|---|---|---|---|---|---|
| none (G_p) | 0 | 1.000 | 0.900 |  |  |  |  |
| ablation | None | 0.000 | 0.900 |  |  |  |  |
| lora | 100 | 0.064 | 0.900 | 0.268 | 5.120 | 0.709 | 3.631 |
| lora | 500 | 0.000 | 0.900 | 0.307 | 2.484 | 0.451 | 1.121 |
| lora | 1000 | 0.000 | 1.000 | 0.342 | 2.071 | 0.358 | 0.742 |
| lora | 1000 | 0.000 | 1.000 | 0.344 | 2.078 | 0.407 | 0.846 |
| oft | 100 | 0.000 |  | 0.266 | 3.103 | 0.183 | 0.567 |
| oft | 500 | 0.000 |  | 0.315 | 2.956 | 0.256 | 0.755 |
| oft | 1000 | 0.000 |  | 0.336 | 1.969 | -0.068 | 0.134 |
| oft | 1000 | 0.000 |  | 0.325 | 1.522 | -0.114 | 0.174 |

_Bias should fall with erosion; high update·D overlap means the fine-tuning moved along the identified direction; a shrinking proj-gap means the bias was removed in D's coordinates._