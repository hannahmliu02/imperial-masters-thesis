# Erosion comparison — ablation vs LoRA vs OFT

Identified candidate: layer [31], k=5, alignment=0.948364406345225.

| method | n_train | bias | capability | update·D (max cos) | demo-strength after | cos(new,D) | proj-gap after |
|---|---|---|---|---|---|---|---|
| none (G_p) | 0 | 1.000 | 0.700 |  |  |  |  |
| ablation | None | 0.672 | 0.700 |  |  |  |  |
| lora | 100 | 0.359 | 0.700 | 0.586 | 5.106 | 0.482 | 2.462 |
| lora | 500 | 0.000 | 0.600 | 0.552 | 4.275 | 0.317 | 1.357 |
| lora | 1000 | 0.000 | 0.700 | 0.564 | 5.104 | 0.587 | 2.995 |
| lora | 1000 | 0.000 | 0.700 | 0.586 | 4.962 | 0.627 | 3.111 |
| oft | 100 | 0.003 |  | 0.569 | 4.636 | 0.301 | 1.394 |
| oft | 500 | 0.001 |  | 0.552 | 2.219 | -0.002 | 0.003 |
| oft | 1000 | 0.000 |  | 0.551 | 6.646 | 0.148 | 0.987 |
| oft | 1000 | 0.001 |  | 0.549 | 10.682 | 0.243 | 2.599 |

_Bias should fall with erosion; high update·D overlap means the fine-tuning moved along the identified direction; a shrinking proj-gap means the bias was removed in D's coordinates._