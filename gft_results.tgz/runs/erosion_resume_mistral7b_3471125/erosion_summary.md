# Erosion comparison — ablation vs LoRA vs OFT

Identified candidate: layer [31], k=5, alignment=0.9649956188972626.

| method | n_train | bias | capability | update·D (max cos) | demo-strength after | cos(new,D) | proj-gap after |
|---|---|---|---|---|---|---|---|
| none (G_p) | 0 | 1.000 | 0.900 |  |  |  |  |
| ablation | None | 0.365 | 0.900 |  |  |  |  |
| lora | 100 | 0.065 | 0.833 | 0.479 | 4.716 | 0.315 | 1.486 |
| lora | 500 | 0.000 | 0.900 | 0.507 | 6.035 | 0.582 | 3.514 |
| lora | 1000 | 0.000 | 0.900 | 0.484 | 7.688 | 0.587 | 4.515 |
| lora | 1000 | 0.000 | 0.900 | 0.504 | 6.211 | 0.443 | 2.753 |
| oft | 100 | 0.000 |  | 0.339 | 2.537 | 0.036 | 0.092 |
| oft | 500 | 0.000 |  | 0.369 | 7.791 | -0.070 | 0.549 |
| oft | 1000 | 0.000 |  | 0.379 | 4.859 | 0.239 | 1.159 |
| oft | 1000 | 0.000 |  | 0.343 | 1.948 | 0.135 | 0.263 |

_Bias should fall with erosion; high update·D overlap means the fine-tuning moved along the identified direction; a shrinking proj-gap means the bias was removed in D's coordinates._