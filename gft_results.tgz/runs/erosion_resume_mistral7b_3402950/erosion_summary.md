# Erosion comparison — ablation vs LoRA vs OFT

Identified candidate: layer [31], k=5, alignment=0.9386552561757316.

| method | n_train | bias | capability | update·D (max cos) | demo-strength after | cos(new,D) | proj-gap after |
|---|---|---|---|---|---|---|---|
| none (G_p) | 0 | 1.000 | 0.800 |  |  |  |  |
| oft | 100 | 0.027 |  | 0.410 | 5.682 | 0.124 | 0.702 |
| oft | 500 | 0.025 |  | 0.377 | 10.187 | 0.017 | 0.174 |
| oft | 1000 | 0.000 |  | 0.459 | 5.959 | 0.035 | 0.209 |
| oft | 1000 | 0.000 |  | 0.424 | 15.470 | 0.140 | 2.170 |

_Bias should fall with erosion; high update·D overlap means the fine-tuning moved along the identified direction; a shrinking proj-gap means the bias was removed in D's coordinates._