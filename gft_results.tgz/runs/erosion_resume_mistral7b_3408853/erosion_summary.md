# Erosion comparison — ablation vs LoRA vs OFT

Identified candidate: layer [31], k=5, alignment=0.9199119058102604.

| method | n_train | bias | capability | update·D (max cos) | demo-strength after | cos(new,D) | proj-gap after |
|---|---|---|---|---|---|---|---|
| none (G_p) | 0 | 1.000 | 0.600 |  |  |  |  |
| ablation | None | 0.914 | 0.600 |  |  |  |  |
| lora | 100 | 0.118 | 0.714 | 0.512 | 4.901 | 0.266 | 1.302 |
| lora | 500 | 0.000 | 0.700 | 0.509 | 4.234 | 0.412 | 1.743 |
| lora | 1000 | 0.000 | 0.700 | 0.535 | 4.331 | 0.291 | 1.258 |
| lora | 1000 | 0.000 | 0.600 | 0.528 | 4.369 | 0.377 | 1.647 |
| oft | 100 | 0.000 |  | 0.418 | 3.032 | 0.065 | 0.197 |
| oft | 500 | 0.000 |  | 0.432 | 6.740 | 0.099 | 0.668 |
| oft | 1000 | 0.000 |  | 0.437 | 6.376 | 0.231 | 1.471 |
| oft | 1000 | 0.000 |  | 0.462 | 5.049 | 0.289 | 1.460 |

_Bias should fall with erosion; high update·D overlap means the fine-tuning moved along the identified direction; a shrinking proj-gap means the bias was removed in D's coordinates._