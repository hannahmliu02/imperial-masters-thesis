# Erosion comparison — ablation vs LoRA vs OFT

Identified candidate: layer [31], k=5, alignment=0.9399625137430864.

| method | n_train | bias | capability | update·D (max cos) | demo-strength after | cos(new,D) | proj-gap after |
|---|---|---|---|---|---|---|---|
| none (G_p) | 0 | 1.000 | 0.800 |  |  |  |  |
| ablation | None | 0.755 | 1.000 |  |  |  |  |
| lora | 100 | 0.021 | 0.900 | 0.550 | 4.573 | 0.534 | 2.440 |
| lora | 500 | 0.000 | 0.800 | 0.509 | 3.812 | 0.027 | 0.104 |
| lora | 1000 | 0.000 | 0.900 | 0.459 | 3.346 | 0.226 | 0.757 |
| lora | 1000 | 0.000 | 0.800 | 0.458 | 4.295 | 0.461 | 1.982 |
| oft | 100 | 0.011 |  | 0.413 | 3.150 | 0.093 | 0.292 |
| oft | 500 | 0.000 |  | 0.412 | 7.326 | 0.008 | 0.060 |
| oft | 1000 | 0.000 |  | 0.434 | 5.750 | 0.074 | 0.425 |
| oft | 1000 | 0.000 |  | 0.448 | 5.255 | 0.176 | 0.926 |

_Bias should fall with erosion; high update·D overlap means the fine-tuning moved along the identified direction; a shrinking proj-gap means the bias was removed in D's coordinates._