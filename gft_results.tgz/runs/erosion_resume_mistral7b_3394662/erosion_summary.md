# Erosion comparison — ablation vs LoRA vs OFT

Identified candidate: layer [31], k=5, alignment=0.9258463535547664.

| method | n_train | bias | capability | update·D (max cos) | demo-strength after | cos(new,D) | proj-gap after |
|---|---|---|---|---|---|---|---|
| none (G_p) | 0 | 1.000 | 0.600 |  |  |  |  |
| ablation | None | 0.072 | 0.700 |  |  |  |  |
| lora | 100 | 0.001 | 0.500 | 0.556 | 5.337 | 0.546 | 2.913 |
| lora | 500 | 0.000 | 0.500 | 0.488 | 4.452 | 0.594 | 2.643 |
| lora | 1000 | 0.000 | 0.700 | 0.540 | 4.830 | 0.541 | 2.614 |
| lora | 1000 | 0.000 | 0.500 | 0.522 | 4.765 | 0.575 | 2.740 |
| oft | 100 | 0.000 |  | 0.305 | 4707.465 | -0.038 | 180.049 |
| oft | 500 | 0.000 |  | 0.338 | 8265325.618 | 0.009 | 76728.671 |
| oft | 1000 | 0.000 |  | 0.292 | 2296451653.138 | -0.007 | 15348714.028 |
| oft | 1000 | 0.001 |  | 0.315 | 6706297.688 | 0.011 | 70909.212 |

_Bias should fall with erosion; high update·D overlap means the fine-tuning moved along the identified direction; a shrinking proj-gap means the bias was removed in D's coordinates._