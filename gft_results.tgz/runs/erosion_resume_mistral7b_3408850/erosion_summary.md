# Erosion comparison — ablation vs LoRA vs OFT

Identified candidate: layer [31], k=5, alignment=0.9262892677150761.

| method | n_train | bias | capability | update·D (max cos) | demo-strength after | cos(new,D) | proj-gap after |
|---|---|---|---|---|---|---|---|
| none (G_p) | 0 | 1.000 | 0.400 |  |  |  |  |
| ablation | None | 0.861 | 0.400 |  |  |  |  |
| lora | 100 | 0.010 |  | 0.445 | 6.857 | 0.267 | 1.828 |
| lora | 500 | 0.000 | 0.500 | 0.529 | 6.071 | 0.405 | 2.456 |
| lora | 1000 | 0.000 | 0.667 | 0.504 | 3.963 | 0.273 | 1.083 |
| lora | 1000 | 0.000 | 0.667 | 0.529 | 5.160 | 0.317 | 1.638 |
| oft | 100 | 0.002 |  | 0.434 | 4.223 | 0.117 | 0.496 |
| oft | 500 | 0.001 |  | 0.402 | 25.904 | -0.018 | 0.463 |
| oft | 1000 | 0.000 | 0.000 | 0.428 | 9.271 | -0.030 | 0.275 |
| oft | 1000 | 0.000 |  | 0.455 | 6.098 | 0.300 | 1.830 |

_Bias should fall with erosion; high update·D overlap means the fine-tuning moved along the identified direction; a shrinking proj-gap means the bias was removed in D's coordinates._