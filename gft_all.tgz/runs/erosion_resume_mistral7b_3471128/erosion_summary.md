# Erosion comparison — ablation vs LoRA vs OFT

Identified candidate: layer [31], k=5, alignment=0.9387882868653777.

| method | n_train | bias | capability | update·D (max cos) | demo-strength after | cos(new,D) | proj-gap after |
|---|---|---|---|---|---|---|---|
| none (G_p) | 0 | 1.000 | 0.900 |  |  |  |  |
| ablation | None | 0.862 | 0.900 |  |  |  |  |
| lora | 100 | 0.140 | 1.000 | 0.434 | 3.885 | 0.396 | 1.538 |
| lora | 200 | 0.000 | 0.900 | 0.471 | 4.249 | 0.431 | 1.830 |
| lora | 300 | 0.192 | 0.900 | 0.466 | 3.222 | 0.378 | 1.217 |
| lora | 400 | 0.000 | 0.900 | 0.472 | 4.657 | 0.526 | 2.448 |
| lora | 500 | 0.000 | 0.900 | 0.498 | 4.914 | 0.471 | 2.314 |
| lora | 750 | 0.000 | 1.000 | 0.488 | 2.515 | 0.056 | 0.140 |
| lora | 1000 | 0.000 | 0.900 | 0.457 | 4.121 | 0.478 | 1.971 |
| oft | 100 | 0.000 |  | 0.382 | 7.176 | -0.010 | 0.074 |
| oft | 200 | 0.128 |  | 0.411 | 6.382 | 0.274 | 1.751 |
| oft | 300 | 0.017 |  | 0.416 | 2.170 | 0.092 | 0.200 |
| oft | 400 | 0.056 |  | 0.417 | 4.693 | 0.134 | 0.630 |
| oft | 500 | 0.001 |  | 0.434 | 13.605 | -0.000 | 0.000 |
| oft | 750 | 0.000 |  | 0.450 | 2.073 | -0.034 | 0.071 |
| oft | 1000 | 0.000 |  | 0.412 | 6.110 | 0.077 | 0.468 |

_Bias should fall with erosion; high update·D overlap means the fine-tuning moved along the identified direction; a shrinking proj-gap means the bias was removed in D's coordinates._