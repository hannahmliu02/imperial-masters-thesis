# Erosion comparison — ablation vs LoRA vs OFT

Identified candidate: layer [31], k=5, alignment=0.9541628931849115.

| method | n_train | bias | capability | update·D (max cos) | demo-strength after | cos(new,D) | proj-gap after |
|---|---|---|---|---|---|---|---|
| none (G_p) | 0 | 1.000 | 0.900 |  |  |  |  |
| ablation | None | 0.011 | 0.900 |  |  |  |  |
| lora | 100 | 0.011 | 0.900 | 0.406 | 3.638 | 0.272 | 0.990 |
| lora | 200 | 0.000 | 0.900 | 0.429 | 3.315 | 0.071 | 0.235 |
| lora | 300 | 0.000 | 0.800 | 0.451 | 6.417 | 0.557 | 3.575 |
| lora | 400 | 0.000 | 0.800 | 0.436 | 4.207 | 0.333 | 1.401 |
| lora | 500 | 0.000 | 0.800 | 0.446 | 4.217 | 0.292 | 1.231 |
| lora | 750 | 0.000 | 0.900 | 0.451 | 3.778 | 0.292 | 1.105 |
| lora | 1000 | 0.000 | 0.900 | 0.440 | 4.349 | 0.393 | 1.707 |
| oft | 100 | 0.010 |  | 0.412 | 1.788 | 0.097 | 0.174 |
| oft | 200 | 0.000 |  | 0.387 | 4.898 | 0.267 | 1.308 |
| oft | 300 | 0.002 |  | 0.378 | 1.552 | -0.023 | 0.036 |
| oft | 400 | 0.000 |  | 0.392 | 5.652 | 0.126 | 0.714 |
| oft | 500 | 0.000 |  | 0.384 | 5.883 | 0.016 | 0.095 |
| oft | 750 | 0.000 |  | 0.435 | 4.898 | 0.056 | 0.273 |
| oft | 1000 | 0.000 |  | 0.410 | 11.183 | 0.183 | 2.045 |

_Bias should fall with erosion; high update·D overlap means the fine-tuning moved along the identified direction; a shrinking proj-gap means the bias was removed in D's coordinates._