# Erosion comparison — ablation vs LoRA vs OFT

Identified candidate: layer [31], k=5, alignment=0.9350279025815842.

| method | n_train | bias | capability | update·D (max cos) | demo-strength after | cos(new,D) | proj-gap after |
|---|---|---|---|---|---|---|---|
| none (G_p) | 0 | 1.000 | 0.900 |  |  |  |  |
| ablation | None | 0.817 | 0.900 |  |  |  |  |
| lora | 100 | 0.353 | 1.000 | 0.551 | 3.529 | 0.422 | 1.488 |
| lora | 200 | 0.000 | 0.900 | 0.590 | 4.645 | 0.239 | 1.110 |
| lora | 300 | 0.000 | 0.400 | 0.532 | 2.663 | -0.000 | 0.001 |
| lora | 400 | 0.000 | 0.857 | 0.524 | 2.870 | -0.003 | 0.008 |
| lora | 500 | 0.000 | 0.900 | 0.509 | 3.934 | 0.391 | 1.540 |
| lora | 750 | 0.000 | 0.889 | 0.574 | 3.434 | -0.038 | 0.131 |
| lora | 1000 | 0.000 | 0.900 | 0.533 | 2.948 | 0.108 | 0.318 |
| oft | 100 | 0.001 |  | 0.447 | 3.026 | 0.088 | 0.265 |
| oft | 200 | 0.001 |  | 0.422 | 1.923 | -0.007 | 0.014 |
| oft | 300 | 0.004 |  | 0.446 | 2.948 | -0.011 | 0.033 |
| oft | 400 | 0.000 |  | 0.447 | 5.294 | 0.141 | 0.747 |
| oft | 500 | 0.118 |  | 0.440 | 16.023 | -0.071 | 1.138 |
| oft | 750 | 0.000 |  | 0.462 | 12.940 | 0.024 | 0.317 |
| oft | 1000 | 0.000 |  | 0.446 | 3.312 | -0.048 | 0.157 |

_Bias should fall with erosion; high update·D overlap means the fine-tuning moved along the identified direction; a shrinking proj-gap means the bias was removed in D's coordinates._