# Erosion comparison — ablation vs LoRA vs OFT

Identified candidate: layer [29], k=5, alignment=0.970658362113797.

| method | n_train | bias | capability | update·D (max cos) | demo-strength after | cos(new,D) | proj-gap after |
|---|---|---|---|---|---|---|---|
| none (G_p) | 0 | 1.000 | 0.900 |  |  |  |  |
| ablation | None | 0.062 | 0.900 |  |  |  |  |
| lora | 100 | 0.000 | 1.000 | 0.318 | 3.860 | 0.389 | 1.502 |
| lora | 200 | 0.000 | 0.900 | 0.314 | 3.005 | 0.267 | 0.802 |
| lora | 300 | 0.000 | 1.000 | 0.281 | 3.307 | 0.572 | 1.890 |
| lora | 400 | 0.000 | 0.778 | 0.295 | 1.931 | 0.142 | 0.275 |
| lora | 500 | 0.000 | 0.800 | 0.288 | 4.897 | 0.761 | 3.725 |
| lora | 750 | 0.000 | 0.833 | 0.275 | 2.548 | 0.431 | 1.099 |
| lora | 1000 | 0.000 | 0.800 | 0.315 | 3.357 | 0.241 | 0.810 |
| oft | 100 | 0.001 |  | 0.243 | 8.198 | 0.283 | 2.319 |
| oft | 200 | 0.000 |  | 0.269 | 4.231 | -0.113 | 0.478 |
| oft | 300 | 0.000 |  | 0.273 | 8.837 | 0.046 | 0.410 |
| oft | 400 | 0.064 |  | 0.262 | 7.003 | 0.128 | 0.894 |
| oft | 500 | 0.000 |  | 0.257 | 4.388 | 0.224 | 0.983 |
| oft | 750 | 0.000 |  | 0.261 | 13.112 | 0.288 | 3.772 |
| oft | 1000 | 0.000 |  | 0.275 | 5.078 | 0.186 | 0.944 |

_Bias should fall with erosion; high update·D overlap means the fine-tuning moved along the identified direction; a shrinking proj-gap means the bias was removed in D's coordinates._